import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;


public class LogicaKruskal{

    public ArrayList<String> parentesco = new ArrayList<>();
    public ArrayList<Tupla> T = new ArrayList<>();
    //public ArrayList<Tupla> Aristas = new ArrayList<>();
    public Tupla[] AristasNueva;
    public Map<String,Integer> referencias = new HashMap<>();
    public LeerTXT leerTXT;
    public OrdenamientoAristas ord = new OrdenamientoAristas();

    public LogicaKruskal(Tupla[] AristasNueva,ArrayList<String> parentesco,
    Map<String,Integer> referencias){
    this.parentesco = parentesco;
    this.referencias = referencias;
    this.AristasNueva = AristasNueva;
    }


    public boolean allSameFather(){
        String fst = ""; 
        for(int i = 0; i < parentesco.size(); i++){
            if(i == 0){
               fst  = parentesco.get(i);
            }else{
                String rst = parentesco.get(i);
                System.out.println("Esta en allsame father");
              if (sameFather(fst, rst) == false ){
                  return false;
              }
            }
        }
       return true;
    }

    private boolean sameFather(String a, String b){
        System.out.println("a" + a);
        System.out.println("b" + b);
        int indexFatherA = referencias.get(a);
        int indexFatherB = referencias.get(b);
        String fatherA, fatherB;
        System.out.println("indexA " + indexFatherA);
        System.out.println("IndexB " + indexFatherB);
        fatherA = parentesco.get(indexFatherA);
        fatherB = parentesco.get(indexFatherB);
        System.out.println("Padre a " + fatherA);
        System.out.println("Padre b " + fatherB);
         if(fatherA.equals(a) && fatherB.equals(b)){
            System.out.println("AQUI");
            return fatherA.equals(fatherB);
         }else if(fatherA.equals(a) &&  fatherB.equals(b) == false){
            return sameFather(a, fatherB);
         }else if(fatherA.equals(a) == false &&  fatherB.equals(b)){
            return sameFather(fatherA, b);
         }else{
            return sameFather(fatherA, fatherB);
         }
    }

    private String getFather(String a){
        int indexFatherA = referencias.get(a);
        String fatherA;
        fatherA = parentesco.get(indexFatherA);
         if(fatherA.equals(a)){
            return fatherA;
         }else{
            return getFather(fatherA);
         }
    }

    private void changesFather(String a , String b){
        String fatherA, fatherB;
        int indexFatherB;
        fatherA = getFather(a);
        fatherB = getFather(b);
        indexFatherB = referencias.get(fatherB);
        parentesco.add(indexFatherB, fatherA);  
        System.out.println("ChangesFather :");
        imprimirParentesco();

    }

    /**
     * Generar un metodo que llene el parentesco
     */

    public void KruskalUCA(){
         String arista = "";
         int peso = 0;
         Tupla tuplaAux;
         int i = 0;
         String key,aS,bS;
         int value;
         int n = AristasNueva.length;
        ord.sort3(AristasNueva, 0, n-1);
        ord.printArray(AristasNueva);
        System.out.println(allSameFather());
        while(allSameFather() == false){
            System.out.println("Entra al ciclo de Kruskal");
            tuplaAux = AristasNueva[i];
            key = tuplaAux.getKey();
            value = tuplaAux.getValue();
            aS = Character.toString( key.charAt(0));
            bS = Character.toString( key.charAt(1));
            System.out.println("AS" + aS);
            System.out.println("BS" + bS);
            Boolean entrar = sameFather(aS, bS);
            System.out.println(" Entrar " + entrar);  
            if(entrar == false ){             
                 changesFather(aS, bS);
                 T.add(tuplaAux);
            }
            i++;
        }

        imprimirT();
    }

    public void imprimirParentesco(){
        System.out.println("Parentestco :");
        System.out.println(parentesco.size());
        for (String a : parentesco) {
          System.out.println(a);
          
        }
    }

    public void imprimirT(){
        System.out.println("El arbol final contiene las siguientes aristas :");
        for (Tupla t : T) {
            String cadena = "<" + t.getKey() + "," + t.getValue() + ">";
            System.out.println(cadena);
        }
    }

}