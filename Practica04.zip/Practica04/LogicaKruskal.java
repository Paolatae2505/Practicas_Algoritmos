import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;


public class LogicaKruskal{

    public ArrayList<String> parentesco = new ArrayList<>();
    public ArrayList<Tupla> T = new ArrayList<>();
    public ArrayList<Tupla> Aristas = new ArrayList<>();
    public Map<String,Integer> referencias = new HashMap<>();
    public LeerTXT leerTXT;
    public OrdenamientoAristas ord = new OrdenamientoAristas();

    public void CrearGrafica(String path){
        leerTXT = new LeerTXT(path);
        leerTXT.inicializarGrafica(parentesco, Aristas,referencias);
    }

    public void ordenarAristas(){
        int der = Aristas.size();
        ord.mergeSortTuplas(Aristas, 0, der);
          
    }

    public boolean allSameFather(){
        String fst = ""; 
        for(int i = 0; i < parentesco.size(); i++){
            if(i == 0){
               fst  = parentesco.get(i);
            }else{
                String rst = parentesco.get(i);
              if (sameFather(rst, fst) == false ){
                  return false;
              }
            }
        }
       return true;
    }

    public boolean sameFather(String a, String b){
        int indexFatherA = referencias.get(a);
        int indexFatherB = referencias.get(b);
        String fatherA, fatherB;
        fatherA = parentesco.get(indexFatherA);
        fatherB = parentesco.get(indexFatherB);
         if(fatherA.equals(a) && fatherB.equals(b)){
            return fatherA.equals(fatherB);
         }else if(fatherA.equals(a) &&  fatherB.equals(b) == false){
            return sameFather(a, fatherB);
         }else if(fatherA.equals(a) == false &&  fatherB.equals(b)){
            return sameFather(fatherA, b);
         }else{
            return sameFather(fatherA, fatherB);
         }
    }

    public String getFather(String a){
        int indexFatherA = referencias.get(a);
        String fatherA;
        fatherA = parentesco.get(indexFatherA);
         if(fatherA.equals(a)){
            return fatherA;
         }else{
            return getFather(fatherA);
         }
    }

    public void changesFather(String a , String b){
        String fatherA, fatherB;
        int indexFatherB;
        fatherA = getFather(a);
        fatherB = getFather(b);
        indexFatherB = referencias.get(fatherB);
        parentesco.add(indexFatherB, fatherA);  
    }

    /**
     * Generar un metodo que llene el parentesco
     */

    public ArrayList<Tupla> KruskalUCA(){
         String arista = "";
         int peso = 0;
         Tupla tuplaAux;
         int i = 0;
         String key,aS,bS;
         int value;
        while(allSameFather() == false){
            tuplaAux = Aristas.get(0);
            key = tuplaAux.getKey();
            value = tuplaAux.getValue();
            aS = Character.toString( key.charAt(0));
            bS = Character.toString( key.charAt(1));
            if(sameFather(aS, bS) == false ){               
                 changesFather(aS, bS);
                 T.add(tuplaAux);
            }

        }
        return T;
    }

    public void printArray(int arr[]) {
        int n = arr.length;
        for (int i=0; i<n; ++i) {
            System.out.println(arr[i] + " ");
        }
        System.out.println();
    }

}