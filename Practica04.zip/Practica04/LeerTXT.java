import java.io.FileInputStream;
import java.io.InputStream;
import java.util.*;
/**
 * Clase LeerDocumento
 * @author Vargas Bravo Paola
 * @version 1.0 (21 Septiembre 2022)
 * @since Analsis de Algortimos (2023-1)
 */
public class LeerTXT {
    private String path ;
    /**
     * Crea una instancia LeerDocumento a partir del path
     * para poder leer el documento y genera la grafica
     * @param path --- String Ruta de la grafica txt
     */
    public LeerTXT(String path){
       this.path = path;
    }
    /**
     * Crea una grafica apatir de la lectura del documento txt
     * @return ---- Map<String, ArrayList<String>> grafica a partir
     *              del documento txt
     */
    public void inicializarGrafica(ArrayList<String> parentesco,
    ArrayList<Tupla> Aristas , Map<String,Integer> referencias){
        ArrayList<String>  lineas = new ArrayList<>();
        Tupla [] AristasNueva;
        String [] aristas = null;
        String [] vertex = null;
        String verticeInicial = "";
        String verticeFinal = "";
        String vertices = "";
        Tupla tuplaAux = null;
        int peso = 0;
        String pesoString = "";
        try{
            String linea = "";
            InputStream ins = new FileInputStream(path);
            Scanner obj = new Scanner(ins);
            int z = 0;
            while (obj.hasNextLine()){
                linea = obj.nextLine();
                if(z == 0){
                    z++;
                   vertices = linea;  
                 }else if(z > 0) {
                    lineas.add(linea);
                }             
            }
        }catch(Exception e){
        }
        vertex = vertices.split(",",-1);
        for(int i = 0 ; i <= vertex.length - 1; i++){
           //aristasGrafica = new ArrayList<>();
           String vertexAux = vertex[i];   ///// OBTENEMOS LOS VERTIICES 
           parentesco.add(vertexAux);
           referencias.put(vertexAux,i);
           //vecinosVertice.put(vertexAux, aristasGrafica);
        }

         int j  = 0;
           AristasNueva = new Tupla[lineas.size()];
          for(String id : lineas){
            aristas = id.split(",",-1);
            verticeInicial = aristas[0];
            verticeFinal = aristas[1]; 
            pesoString = aristas[2];
            peso = Integer.parseInt(pesoString);
            String union = verticeInicial + verticeFinal;
            tuplaAux = new Tupla(union, peso);
            AristasNueva[j] = tuplaAux;
            j ++;
            //Aristas.add(tuplaAux);
           // aristasGrafica = new ArrayList<>();
            //aristasGrafica = vecinosVertice.get(verticeInicial);
            //aristasGrafica.add(verticeFinal);  /// OBTENEMOS LAS ARISTAS
            //vecinosVertice.put(verticeInicial,aristasGrafica);
          }
    }
}
