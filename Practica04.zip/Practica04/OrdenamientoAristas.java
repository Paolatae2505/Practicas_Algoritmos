import java.util.ArrayList;

public class OrdenamientoAristas {
 
    public void mergeSortTuplas(ArrayList<Tupla> A, int izq, int der){
        if (izq < der){
            int m=(izq+der)/2;
            mergeSortTuplas(A,izq, m);
            mergeSortTuplas(A,m+1, der);                                                                                
            mergeTupla(A,izq, m, der);                                                                                 
    }
    }
   public void mergeTupla(ArrayList<Tupla> A, int izq,int m, int der){
    int i, j, k;
    ArrayList<Tupla> B = new ArrayList<>(); //array auxiliar
    Tupla tuplaAux;
    Tupla tuplaAux2;
    int value;
    int value2;
    Tupla tuplaAux3;
    Tupla tuplaAux4;
 
    for (i=izq; i<=der; i++){
        tuplaAux = A.get(i);
        B.add(i, tuplaAux);
    }                                      
        
    i=izq; j=m+1; k=izq;
      
    while (i<=m && j<=der) {//copia el siguiente elemento más grande   
           tuplaAux = B.get(i); 
           tuplaAux2 = B.get(j);
           value = tuplaAux.getValue();
           value2 = tuplaAux2.getValue();                                
           if (value<=value2){
              tuplaAux3 = A.get(k++);
              B.add(i++, tuplaAux3);
           }else{
               tuplaAux3 = A.get(k++);
               B.add(j++,tuplaAux3);
           }
    }
         
    while (i<=m){
        tuplaAux4 = A.get(k++);
        B.add(i++, tuplaAux4);
    }         

   }

   public void sort(ArrayList<Tupla> A, int left, int right){
    if(left < right){
        //Encuentra el punto medio del vector.
        int m = (left + right) / 2;
        
        //Divide la primera y segunda mitad (llamada recursiva).
        sort(A, left, m);
        sort(A, m + 1 , right);
  
        //Une las mitades.
        merge(A, left, m, right);
      }
  }


  public void merge(ArrayList<Tupla> A, int left, int middle, int right) {
    //Encuentra el tamaño de los sub-vectores para unirlos.
    int n1 = middle - left + 1;
    int n2 = right - middle;
  
    //Vectores temporales.
    ArrayList<Tupla> leftArray = new ArrayList<>();
    ArrayList<Tupla> rightArray = new ArrayList<>();

     Tupla aux;
     Tupla aux2;
    //Copia los datos a los arrays temporales.
    for (int i=0; i < n1; i++) {
        aux = A.get(i);
        leftArray.add(i,aux);
     // leftArray[i] = arr[left+i];
    }
    for (int j=0; j < n2; j++) {
        aux = A.get(j);
        rightArray.add(middle + j + 1,aux);
      //rightArray[j] = arr[middle + j + 1];
    }
    /* Une los vectorestemporales. */
  
    //Índices inicial del primer y segundo sub-vector.
    int i = 0, j = 0;
  
    //Índice inicial del sub-vector arr[].
    int k = left;
  
    //Ordenamiento.
    while (i < n1 && j < n2) {
        aux = leftArray.get(i);
        aux2 = rightArray.get(j);
      if (aux.getValue() <= aux2.getValue()) {
        A.add(k,leftArray.get(i));
        i++;
      } else {
        A.add(k,rightArray.get(j));
         // arr[k] = rightArray[j];
          j++;
      }
      k++;
    }//Fin del while.
  
    /* Si quedan elementos por ordenar */
    //Copiar los elementos restantes de leftArray[].
    while (i < n1) {
      A.add(k,leftArray.get(i));
     // arr[k] = leftArray[i];
      i++;
      k++;
    }
    //Copiar los elementos restantes de rightArray[].
    while (j < n2) {
      A.add(k,rightArray.get(j));
      //arr[k] = rightArray[j];
      j++;
      k++;
    }
  }

  public void sort2(int arr[], int left, int right){
    if(left < right){
      //Encuentra el punto medio del vector.
      int m = (left + right) / 2;
      
      //Divide la primera y segunda mitad (llamada recursiva).
      sort2(arr, left, m);
      sort2(arr, m + 1, right);

      //Une las mitades.
      merge2(arr, left, m, right);
    }
}

public void merge2(int arr[], int left, int middle, int right) {
    //Encuentra el tamaño de los sub-vectores para unirlos.
    int n1 = middle - left + 1;
    int n2 = right - middle;
  
    //Vectores temporales.
    int leftArray[] = new int [n1];
    int rightArray[] = new int [n2];
  
    //Copia los datos a los arrays temporales.
    for (int i=0; i < n1; i++) {
      leftArray[i] = arr[left+i];
    }
    for (int j=0; j < n2; j++) {
      rightArray[j] = arr[middle + j + 1];
    }
    /* Une los vectorestemporales. */
  
    //Índices inicial del primer y segundo sub-vector.
    int i = 0, j = 0;
  
    //Índice inicial del sub-vector arr[].
    int k = left;
  
    //Ordenamiento.
    while (i < n1 && j < n2) {
      if (leftArray[i] <= rightArray[j]) {
        arr[k] = leftArray[i];
        i++;
      } else {
          arr[k] = rightArray[j];
          j++;
      }
      k++;
    }//Fin del while.
  
    /* Si quedan elementos por ordenar */
    //Copiar los elementos restantes de leftArray[].
    while (i < n1) {
      arr[k] = leftArray[i];
      i++;
      k++;
    }
    //Copiar los elementos restantes de rightArray[].
    while (j < n2) {
      arr[k] = rightArray[j];
      j++;
      k++;
    }
  }



///////////////

public void sort3(Tupla arr[], int left, int right){
    if(left < right){
      //Encuentra el punto medio del vector.
      int m = (left + right) / 2;
      
      //Divide la primera y segunda mitad (llamada recursiva).
      sort3(arr, left, m);
      sort3(arr, m + 1, right);

      //Une las mitades.
      merge3(arr, left, m, right);
    }
}

public void merge3(Tupla arr[], int left, int middle, int right) {
    //Encuentra el tamaño de los sub-vectores para unirlos.
    int n1 = middle - left + 1;
    int n2 = right - middle;
  
    //Vectores temporales.
    Tupla leftArray[] = new Tupla [n1];
    Tupla rightArray[] = new Tupla [n2];

    Tupla aux;
  
    //Copia los datos a los arrays temporales.
    for (int i=0; i < n1; i++) {
      leftArray[i] = arr[left+i];
    }
    for (int j=0; j < n2; j++) {
      rightArray[j] = arr[middle + j + 1];
    }
    /* Une los vectorestemporales. */
  
    //Índices inicial del primer y segundo sub-vector.
    int i = 0, j = 0;
  
    //Índice inicial del sub-vector arr[].
    int k = left;
  
    //Ordenamiento.
    while (i < n1 && j < n2) {
      if (leftArray[i].getValue() <= rightArray[j].getValue()) {
        arr[k] = leftArray[i];
        i++;
      } else {
          arr[k] = rightArray[j];
          j++;
      }
      k++;
    }//Fin del while.
  
    /* Si quedan elementos por ordenar */
    //Copiar los elementos restantes de leftArray[].
    while (i < n1) {
      arr[k] = leftArray[i];
      i++;
      k++;
    }
    //Copiar los elementos restantes de rightArray[].
    while (j < n2) {
      arr[k] = rightArray[j];
      j++;
      k++;
    }
  }

  public void printArray(Tupla arr[]) {
    int n = arr.length;
    for (int i=0; i<n; ++i) {

        System.out.println("<" + arr[i].getKey() + "," + arr[i].getValue() + ">");
    }
    System.out.println();
}


}
