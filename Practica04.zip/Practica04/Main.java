import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
           ArrayList<Tupla> prueba = new ArrayList<>();
           OrdenamientoAristas ord = new OrdenamientoAristas();
           Tupla a = new Tupla("a", 5);
           Tupla b = new Tupla("b", 2);
           Tupla c = new Tupla("c", 7);
           Tupla d = new Tupla("d", 1);
           //int arr [] = {5,26,12,6,1,4,7}
           Tupla arr [] = {a,b,c,d};
       // int n = arr.length;
           //prueba.add(a);
           //prueba.add(b);
           //prueba.add(c);
           //prueba.add(d);
           int n = arr.length;
           ord.sort3(arr, 0, n-1);
          // ord.sort2(arr,0,n-1);
           ord.printArray(arr);
           //ord.mergeSortTuplas(prueba, 0, 3);
           //ord.sort(prueba,0, n-1);

          /**  for (Tupla tupla : prueba) {
                 String cadena = "<" + tupla.getKey() + "," + tupla.getValue() + ">";
                 System.out.println(cadena);
           }
           */

        
    }
}
